Comp20 Assignment 3 - Where in the world
Jessie Chapman
11/20/2014

1. the /locations.json API and /sendLocation API are not working correctly because I was having trouble connecting my app to mongodb, and so was unable to get any working data in my collection to test either API. 

the / index should display the login, lat, and lng for a user (but does not display the timestamp created_at); I was able to test this with local data using curl.

2. Jared Bronen and Brendan Conron helped me out big time on this!

3. ~15 hours
