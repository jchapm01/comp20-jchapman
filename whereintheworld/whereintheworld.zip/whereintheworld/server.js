// Initialization
var mongoUri = process.env.MONGOLAB_URI || process.env.MONGOHQ_URL || "mongodb://localhost:3000/polar-depths-6990";
//var mongoUri = "mongodb://130.64.160.125/a3db";
var collections = ["locations"];
var mongo = require('mongodb');
var db = mongo.connect(mongoUri, function(err, connection){
	if (!err){
		db = connection;
	}
}),
express = require('express'),
util = require('util');
app = express(),
bodyParser = require('body-parser'),
path = require('path'),
http = require('http');

app.use( bodyParser.json() );  //use urlencoded and json body parsers
app.use(bodyParser.urlencoded({ 
  extended: true
})); 
app.use('/',express.static(path.join(__dirname, '/'))); //include static file

// enable cross-origin resource sharing
app.all('*', function(request, response , next) {
  logRequest(request);
  response.header("Access-Control-Allow-Origin", "*");
  response.header("Access-Control-Allow-Headers", "X-Requested-With");
  next();
});

app.get('/', function(request, response){
	db.collection("locations", function(err, collection){
		collection.find({}).sort({created_at: -1}, function(err, locations){
		if(err) response.end("<!DOCTYPE html><html><head><link rel='stylesheet' href='style.css' /></head><body><div id='nolocation' style='text-align:center'><h1>app Error</h1></div></body></html>");
		else{
			var list = "<!DOCTYPE html><html><head><link rel=\'stylesheet\' href=\'style.css\' /></head><body>";
  			if(locations.length === 0){
  				list += "<h1>No locations submitted yet...</h1>";
  			}else{
  				list+= "<table><tr><th>Login</th><th>Latitude</th><th>Longitude</th></tr>"
  				for(var i = 0; i < locations.length; i++){
  					list += '<tr><td>' + locations[i].login + "</td><td>" + locations[i].lat + "</td><td>" + locations[i].lng + '</td></tr>';
  				}
  			}
  			list += "</table></body></html>"
			response.end(list);
		}
	});
	});
});

app.get('/locations.json', function(request, response){
    db.collection("locations", function(err, collection) {
	collection.find({login:request.query.login}).sort({created_at:-1}, function(err, locations){
		if(err){
			response.end(404);
		}
	    else if (login == undefined) {
		response.end("[]");
	    }else{
			response.end(JSON.stringify(locations));
		}
	});
    });
});

app.get('/redline.json', function(request, response){
	var request = http.get("http://developer.mbta.com/lib/rthr/red.json", function(res){
	    var data = "";
		 res.on('data', function (chunk) {
		 	data += chunk.toString();
  		});
		res.on('end', function(){
			response.end(data);
		});
	});
	request.on('error', function(error){
		util.log(error);
	});
});

app.post('/sendLocation', function(request, response){
	var date = new Date();
    db.collection("locations", function(err, collection) {
	collection.save({login: request.body.login, lat:request.body.lat, lng:request.body.lng, created_at:date}, function(err, success){
		if (err || !success) response.end('Not good ' + err);
		else response.end('Object created at: ' + date);
		util.log(err);
	});
    });
});

//Utilities

function logRequest(request){
	util.log(request.method + " request for " + request.path + " from " + request.hostname);
}

var port = process.env.PORT || 3000;
app.listen(port, function(){
	util.log("listening on " + port);
});

// Oh joy! http://stackoverflow.com/questions/15693192/heroku-node-js-error-web-process-failed-to-bind-to-port-within-60-seconds-of
//app.listen(process.env.PORT || 3000);
